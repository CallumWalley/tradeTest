Elements have the following base classes.


## Info
No interactive elements effect game, only UI

## Action
Interactive elements effect game, if clearly interactive elements.
